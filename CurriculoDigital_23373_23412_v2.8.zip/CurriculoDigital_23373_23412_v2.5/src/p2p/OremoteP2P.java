//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: 
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2024   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package p2p;

import blockchain.utils.Block;
import blockchain.utils.BlockChain;
import blockchain.utils.MerkleTree;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import blockchain.utils.Miner;
import curriculodigitalv2.Curriculo;
import curriculodigitalv2.User;
import static curriculodigitalv2.User.FOLDER;
import java.rmi.server.RemoteServer;
import java.rmi.server.ServerNotActiveException;
import java.security.Key;
import java.security.PublicKey;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.ObjectUtils;
import utils.RMI;
import utils.SecurityUtils;

/**
 * Created on 27/11/2024, 17:48:32
 *
 * @author manso - computer
 */
public class OremoteP2P extends UnicastRemoteObject implements IremoteP2P {
    
    Key aesKey;
    
    final static String BLOCHAIN_FILENAME = FOLDER + "/" + "blockchain.bc";
    String address;
    CopyOnWriteArrayList<IremoteP2P> network;
    // Set - conjunto de elementos não repetidos para acesso concorrente
    CopyOnWriteArraySet<String> transactions;
    P2Plistener p2pListener;
    //objeto mineiro concorrente e distribuido
    Miner myMiner;
    //objeto da blockchain preparada para cesso concorrente
    BlockChain myBlockchain;

    public OremoteP2P(String address, P2Plistener listener) throws RemoteException, Exception {
        super(RMI.getAdressPort(address));
        this.address = address;
        this.network = new CopyOnWriteArrayList<>();
        transactions = new CopyOnWriteArraySet<>();
        this.myMiner = new Miner(listener);
        this.myBlockchain = new BlockChain(BLOCHAIN_FILENAME);
        this.p2pListener = listener;
        
        this.aesKey = SecurityUtils.generateAESKey(256);

        listener.onStartRemote("Object " + address + " listening");
        
    }
    
    @Override
    public String sayHello() throws RemoteException {
        String client = "";
        try {
            //nome do cliente
            client = RemoteServer.getClientHost();
            p2pListener.onClient("Cliente Conectado: ", client);
        } catch (ServerNotActiveException ex) {
            System.out.println("Serving anonimous host");
        }
        return address + " say Hello to " + client;
    }
    
    @Override
    public boolean registar(byte[] nomeBytes, byte[] passwordBytes, byte[] typeBytes) throws RemoteException {
        try {
            // Descriptografa os dados recebidos
            byte[] decryptNome = SecurityUtils.decrypt(nomeBytes, aesKey);
            byte[] decryptPassword = SecurityUtils.decrypt(passwordBytes, aesKey);
            byte[] decryptType = SecurityUtils.decrypt(typeBytes, aesKey);
            String nome = new String(decryptNome);
            String pass = new String(decryptPassword);
            int tipo = Integer.parseInt(new String(decryptType));

            // Cria um novo utilizador com os dados descriptografados
            User user = new User(nome, tipo);
            // Gera as chaves para o utilizador
            user.generateKeys();
            // Salva as informações do utilizador com a senha descriptografada
            user.save(pass);
        } catch (Exception e) {
            p2pListener.onException(e, "registo ERROR ");
            // Retorna false em caso de erro
            return false;
        }
        // Sincroniza o utilzador criado para todos os nós
        //synchronizeNetworkFiles();
        // Retorna true se o registo for bem-sucedido
        return true;
    }

    @Override
    public byte[] login(byte[] nomeBytes, byte[] passwordBytes) throws RemoteException {
        try {
            // Descriptografa os dados recebidos
            byte[] decryptNome = SecurityUtils.decrypt(nomeBytes, aesKey);
            byte[] decryptPassword = SecurityUtils.decrypt(passwordBytes, aesKey);
            String nome = new String(decryptNome);
            String pass = new String(decryptPassword);

            // Cria um novo Utilizador com os nome descriptografado 
            User user = new User(nome);
            // Carrega os dados do utilizador com a password descriptografada
            user.load(pass);

            // Converte o objeto do utilizador para um formato Base64
            String userData = ObjectUtils.convertObjectToBase64(user);
            // Criptografa os dados do utilizador antes de enviá-los de volta
            byte[] encryptUser = SecurityUtils.encrypt(userData.getBytes(), aesKey);
            // Retorna os dados criptografados do utilizador
            return encryptUser;
        } catch (Exception e) {
            p2pListener.onException(e, "login ERROR ");
            // Retorna null em caso de erro
            return null;
        }
    }
    
    @Override
    public byte[] getKey(PublicKey pubKey) throws RemoteException{
        try {
            return SecurityUtils.encrypt(aesKey.getEncoded(), pubKey);
        } catch (Exception ex) {
            Logger.getLogger(OremoteP2P.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public String getAdress() throws RemoteException {
        return address;
    }

    /**
     * Método que verifica se um no está na rede e elmina os que não responderem
     *
     * @param adress endereço do no
     * @return true se estiver na rede falso caso contrario
     */
    private boolean isInNetwork(String adress) {
        //fazer o acesso iterado pelo fim do array para remover os nos inativos
        for (int i = network.size() - 1; i >= 0; i--) {
            try {
                //se o no responder e o endereço for igaul
                if (network.get(i).getAdress().equals(adress)) {
                    // no esta na rede 
                    return true;
                }
            } catch (RemoteException ex) {
                //remover os nós que não respondem
                network.remove(i);
            }
        }
        return false;
    }

    @Override
    public void addNode(IremoteP2P node) throws RemoteException {
        //se já tiver o nó  ---  não faz nada
        if (isInNetwork(node.getAdress())) {
            return;
        }
        p2pListener.onMessage("Network addNode ", node.getAdress());
        //adicionar o no á rede
        network.add(node);

        p2pListener.onConect(node.getAdress());
        // pedir ao no para nos adicionar
        node.addNode(this);
        //propagar o no na rede
        for (IremoteP2P iremoteP2P : network) {
            iremoteP2P.addNode(node);
        }

        //sicronizar as transaçoes
        synchronizeCurriculos(node);
        //sincronizar a blockchain
        synchnonizeBlockchain();

    }

    @Override
    public List<IremoteP2P> getNetwork() throws RemoteException {
        return new ArrayList<>(network);
    }

    //::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //::::::::            T R A N S A C T I O N S       ::::::::::::::::::
    //::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    public int getCurriculosSize() throws RemoteException {
        return transactions.size();
    }

    public void addCurriculo(String data) throws RemoteException {
        //seja tiver a transacao não faz nada
        if (transactions.contains(data)) {
            p2pListener.onTransaction("Transaçao repetida " + data);
            //sair
            return;
        }
        //Adicionar a transaçao ao no local
        transactions.add(data);
        //Adicionar a transacao aos nos da rede
        for (IremoteP2P iremoteP2P : network) {
            iremoteP2P.addCurriculo(data);
        }

    }

    @Override
    public List<String> getCurriculos() throws RemoteException {
        return new ArrayList<>(transactions);
    }

    @Override
    public void synchronizeCurriculos(IremoteP2P node) throws RemoteException {
        //tamanho anterior
        int oldsize = transactions.size();
        p2pListener.onMessage("sinchronizeTransactions", node.getAdress());
        // juntar as transacoes todas (SET elimina as repetidas)
        this.transactions.addAll(node.getCurriculos());
        int newSize = transactions.size();
        //se o tamanho for incrementado
        if (oldsize < newSize) {
            p2pListener.onMessage("sinchronizeTransactions", "tamanho diferente");
            //pedir ao no para sincronizar com as nossas
            node.synchronizeCurriculos(this);
            p2pListener.onTransaction(address);
            p2pListener.onMessage("sinchronizeTransactions", "node.sinchronizeTransactions(this)");
            //pedir á rede para se sincronizar
            for (IremoteP2P iremoteP2P : network) {
                //se o tamanho for menor
                if (iremoteP2P.getCurriculosSize() < newSize) {
                    //cincronizar-se com o no actual
                    p2pListener.onMessage("sinchronizeTransactions", " iremoteP2P.sinchronizeTransactions(this)");
                    iremoteP2P.synchronizeCurriculos(this);
                }
            }
        }

    }

    @Override
    public void removeCurriculos(List<String> myTransactions) throws RemoteException {
        //remover as transações da lista atural
        transactions.removeAll(myTransactions);
        p2pListener.onTransaction("remove " + myTransactions.size() + "transactions");
        //propagar as remoções
        for (IremoteP2P iremoteP2P : network) {
            //se houver algum elemento em comum nas transações remotas
            if (iremoteP2P.getCurriculos().retainAll(transactions)) {
                //remover as transaçoies
                iremoteP2P.removeCurriculos(myTransactions);
            }
        }
    }
    
    @Override
    public Set<String> getlistPessoas() throws RemoteException {
        Set<String> nomesPessoas = new HashSet<>();
        for (Block b : myBlockchain.getChain()) {
            try {
                Curriculo c = getCurriculoFromBlock(b);
                nomesPessoas.add(c.getPessoa());
            } catch (Exception ex) {
                Logger.getLogger(OremoteP2P.class.getName()).log(Level.SEVERE, null, ex);
                p2pListener.onException(ex, "getlistPessoas ERROR");
            }
        }
        return nomesPessoas;
    }

    private Curriculo getCurriculoFromBlock(Block b) throws Exception {
        // Carregar a Merkle Tree correspondente ao bloco
        MerkleTree mt = MerkleTree.loadFromFile(sanitizeHashMKT(b.getCurrentHash()));
        // Recuperar o currículo a partir dos elementos da Merkle Tree
        String base64 = (String) mt.getElements().get(0); // Primeiro elemento é o currículo
        // Converte o currículo de Base64 para um objeto Curriculo
        Curriculo c = (Curriculo) ObjectUtils.convertBase64ToObject(base64);

        return c;
    }
    
    @Override
    public List<Curriculo> getCurriculosFromBlockchain() throws RemoteException {
        List<Curriculo> curriculosList = new ArrayList<>();
        for (Block b : myBlockchain.getChain()) {
            try {
                // Carregar a Merkle Tree correspondente ao bloco
                MerkleTree mt = MerkleTree.loadFromFile(sanitizeHashMKT(b.getCurrentHash()));

                // Recuperar o currículo a partir dos elementos da Merkle Tree
                String base64 = (String) mt.getElements().get(0); // Primeiro elemento é o currículo
                // Converte o currículo de Base64 para um objeto Curriculo
                Curriculo curriculo = (Curriculo) ObjectUtils.convertBase64ToObject(base64);

                // Adicionar o currículo e sua validação ao mapa
                curriculosList.add(curriculo);
            } catch (Exception ex) {
                Logger.getLogger(OremoteP2P.class.getName()).log(Level.SEVERE, null, ex);
                p2pListener.onException(ex, "getCurriculosFromBlockchain ERROR");
            }
        }
        return curriculosList;
    }
    
    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //:::::::::::::::::      M I N E R   :::::::::::::::::::::::::::::::::::::::
    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //////////////////////////////////////////////////////////////////////////////

    @Override
    public void startMining(String msg, int zeros) throws RemoteException {
        try {
            //colocar a mineiro a minar
            myMiner.startMining(msg, zeros);
            p2pListener.onStartMining(msg, zeros);
            //mandar minar a rede
            for (IremoteP2P iremoteP2P : network) {
                //se o nodo nao estiver a minar
                if (!iremoteP2P.isMining()) {
                    p2pListener.onStartMining(iremoteP2P.getAdress() + " mining", zeros);
                    //iniciar a mineracao no nodo
                    iremoteP2P.startMining(msg, zeros);
                }
            }
        } catch (Exception ex) {
            p2pListener.onException(ex, "startMining");
        }

    }

    @Override
    public void stopMining(int nonce) throws RemoteException {
        //parar o mineiro e distribuir o nonce
        myMiner.stopMining(nonce);
        //mandar parar a rede
        for (IremoteP2P iremoteP2P : network) {
            //se o nodo estiver a minar   
            if (iremoteP2P.isMining()) {
                //parar a mineração no nodo 
                iremoteP2P.stopMining(nonce);
            }
        }
    }

    @Override
    public int mine(String msg, int zeros) throws RemoteException {
        try {
            //começar a minar a mensagem
            startMining(msg, zeros);
            //esperar que o nonce seja calculado
            return myMiner.waitToNonce();
        } catch (InterruptedException ex) {
            p2pListener.onException(ex, "Mine");
            return -1;
        }

    }

    @Override
    public boolean isMining() throws RemoteException {
        return myMiner.isMining();
    }

    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //::::::::::::::::: B L O C K C H A I N :::::::::::::::::::::::::::::::::::::::
    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //////////////////////////////////////////////////////////////////////////////
    @Override
    public void addBlock(Block b, MerkleTree mt) throws RemoteException {
        try {
            if (myBlockchain.getChain().contains(b)) {
                return;
            }
            //se não for válido
            if (!b.isValid()) {
                throw new RemoteException("invalid block");
            }
            //se encaixar adicionar o bloco
            if (myBlockchain.getLastBlockHash().equals(b.getPreviousHash())) {
                myBlockchain.add(b);
                //guardar a blockchain
                myBlockchain.save(BLOCHAIN_FILENAME);
                mt.saveToFile(sanitizeHashMKT(myBlockchain.getLastBlockHash()));
                
                p2pListener.onBlockchainUpdate(myBlockchain);
            }
            //propagar o bloco pela rede
            for (IremoteP2P iremoteP2P : network) {
                //se encaixar na blockcahin dos nodos remotos
                if (!iremoteP2P.getBlockchainLastHash().equals(b.getPreviousHash())
                        || //ou o tamanho da remota for menor
                        iremoteP2P.getBlockchainSize() < myBlockchain.getSize()) {
                    //adicionar o bloco ao nodo remoto
                    iremoteP2P.addBlock(b, mt);
                }
            }
            //se não encaixou)
            if (!myBlockchain.getLastBlockHash().equals(b.getCurrentHash())) {
                //sincronizar a blockchain
                synchnonizeBlockchain();
            }
        } catch (Exception ex) {
            p2pListener.onException(ex, "Add bloco " + b);
        }
    }
    
    public static String sanitizeHashMKT(String filename){
        String sanitizaName = Base64.getUrlEncoder().withoutPadding().encodeToString(filename.getBytes());
        return FOLDER + "/" + sanitizaName + ".mkt";
    }

    @Override
    public int getBlockchainSize() throws RemoteException {
        return myBlockchain.getSize();
    }

    @Override
    public String getBlockchainLastHash() throws RemoteException {
        return myBlockchain.getLastBlockHash();
    }

    @Override
    public BlockChain getBlockchain() throws RemoteException {
        return myBlockchain;
    }

    @Override
    public void synchnonizeBlockchain() throws RemoteException {
        //para todos os nodos da rede
        for (IremoteP2P iremoteP2P : network) {
            //se a blockchain for maior
            if (iremoteP2P.getBlockchainSize() > myBlockchain.getSize()) {
                BlockChain remote = iremoteP2P.getBlockchain();
                //e a blockchain for válida
                if (remote.isValid()) {
                    //atualizar toda a blockchain
                    myBlockchain = remote;
                    //deveria sincronizar apenas os blocos que faltam
                    p2pListener.onBlockchainUpdate(myBlockchain);
                }
            }
        }
    }
    
    @Override
    public List<String> getBlockchainTransactions()throws RemoteException{
        ArrayList<String> allTransactions = new ArrayList<>();
        for(Block b: myBlockchain.getChain()){
            allTransactions.add(b.getMerkleRoot());
        }
        return allTransactions;
    }
    
    @Override
    public String blockChainToString() throws RemoteException {
        StringBuilder txt = new StringBuilder();
        // Itera por todos os blocos na blockchain
        for (Block b : myBlockchain.getChain()) {
            try {
                // Carregar a Merkle Tree correspondente ao bloco
                MerkleTree mt = MerkleTree.loadFromFile(sanitizeHashMKT(b.getCurrentHash()));
                // Recuperar o currículo a partir dos elementos da Merkle Tree
                String base64 = (String) mt.getElements().get(0); // Primeiro elemento é o currículo

                // Adiciona ao texto a hash anterior, o currículo, o nonce e o hash atual
                txt.append(
                        b.getPreviousHash() + " // " // Hash anterior
                        + mt.getProof(base64) + " // " // Curriculo
                        + b.getNonce() + " // " // Nounce
                        + b.getCurrentHash() // Hash atual
                        + "\n"
                );
            } catch (Exception ex) {
                Logger.getLogger(OremoteP2P.class.getName()).log(Level.SEVERE, null, ex);
                p2pListener.onException(ex, "blockChainToString ERROR");
            }
        }
        // Retorna a representação em string da blockchain
        return txt.toString();
    }

}
