package blockchain.utils;

import utils.SecurityUtils;
import java.math.BigInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Hash {

    public static final String algoritmo = "SHA3-256";

    public static String toHexString(int n) {
        return Integer.toHexString(n).toUpperCase();
    }

    public static String getHash(String data) {
        try {
            byte[] hash = SecurityUtils.calculateHash(data.getBytes(), algoritmo);
            return new BigInteger(hash).abs().toString(16);
        } catch (Exception ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "ERROR in HASH";

    }
    private static final long serialVersionUID = 202209281102L;
}
